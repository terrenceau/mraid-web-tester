/* Copywrite Aron Schatz 2014
 *245195 
 * This IAB MRAID test creative was built by Aron Schatz, currently Editor-in-Chief at ASE Publishing, on 2014-02-07.
 */

function $(element)
{
	element = document.getElementById(element);
	return element;
}
window._aron_init = 0;
window._aron_state='none';
// Viewport setup
var meta = document.querySelector("meta[name=viewport]");
if (!meta)
{
  meta = document.createElement("meta");
  meta.name = "viewport";
  meta.content = "width=device-width,user-scalable=no,initial-scale=1,maximum-scale=1";
  document.getElementsByTagName('head')[0].appendChild(meta);
}
else
{
  meta.content = "width=device-width,user-scalable=no,initial-scale=1,maximum-scale=1";
}

function initad()
{
	//Inject a style
	console.log('initad() triggered.');
	var head = document.getElementsByTagName("head")[0];
	var style = document.createElement('style');
	style.setAttribute('type', 'text/css')
	style.appendChild(document.createTextNode(' body{display:table; height:100%; width:100%;} div#arontwopartwrap{text-align:center; width:100%; background:#000; color:#f00; font-size:12px; font-family:arial;display:table-cell; vertical-align:middle;} a{ line-height:40px; font-size:30px; padding:3px; background:#fff; color:#f00; border:1px solid #f00; display:block; height:40px; width:260px; margin:auto; text-align:center; text-decoration:none;}'));
	head.appendChild(style);
	window._aron_init = 1;

}



function readycheck()
{
	console.log('window.onload() triggered.');
	if(mraid.getState() == 'loading') 
	{
		mraid.addEventListener("ready", initad);  
	}
	else
	{
		initad();
	}
	if(!mraid.isViewable())
	{
	  console.log('Adview is not visible'); //Don't die from this error, just a notice
	}
	mraid.addEventListener('error', mraiderror);
	mraid.addEventListener('stateChange', statechange);
}

function statechange()
{
	console.log("MRAID State Change.");
}

function mraiderror(message,action)
{
	console.log("MRAID Error: '"+message+"' From: "+action);
}

function twopart()
{
  mraid.useCustomClose(true); //No SDK close button.
  mraid.expand("http://www.aronschatz.com/mraid/testads/aron2partmraid2/2part.html"); //Change URL to test other pages
}


if(document.readyState=="complete")
{
	readycheck();
}
else
{
	window.addEventListener('load', readycheck, false); //DOM and MRAID check
}